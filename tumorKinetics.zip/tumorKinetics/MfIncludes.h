#pragma once

#include "SubdividableSphere.h"
#include "Plane.h"

typedef mf::SubdividableSphere<> MfSphere;
typedef mf::Plane<> MfPlane;